// MAGIC EFFECTS
$("#Magic").click(function(){
    $(this).addClass("magictime magic");    
})

$("#twisterInDown").click(function(){
    $(this).addClass("magictime twisterInDown");
})

$("#twisterInUp").click(function(){
    $(this).addClass("magictime twisterInUp");
})

$("#swap").click(function(){
    $(this).addClass("magictime swap");
})
//BLING
$("#puffIn").click(function(){
    $(this).addClass("magictime puffIn");
})

$("#puffOut").click(function(){
    $(this).addClass("magictime puffOut");
})

$("#vanishIn").click(function(){
    $(this).addClass("magictime vanishIn");
})
$("#vanishOut").click(function(){
    $(this).addClass("magictime vanishOut");
})
//STATIC EFFECTS
$("#openDownLeft").click(function(){
    $(this).addClass("magictime openDownLeft");
})

$("#openDownRight").click(function(){
    $(this).addClass("magictime openDownRight");
})

$("#openUpLeft").click(function(){
    $(this).addClass("magictime openUpLeft");
})

$("#openUpRight").click(function(){
    $(this).addClass("magictime openUpRight");
})

$("#openDownLeftReturn").click(function(){
    $(this).addClass("magictime openDownLeftReturn");
})

$("#openDownRightReturn").click(function(){
    $(this).addClass("magictime openDownRightReturn");
})

$("#openUpLeftReturn").click(function(){
    $(this).addClass("magictime openUpLeftReturn");
})

$("#openUpRightReturn").click(function(){
    $(this).addClass("magictime openUpRightReturn");
})
//STATIC EFFECTS OUT
$("#openDownLeftOut").click(function(){
    $(this).addClass("magictime openDownLeftOut");
})
$("#openDownRightOut").click(function(){
    $(this).addClass("magictime openDownRightOut");
})
$("#openUpLeftOut").click(function(){
    $(this).addClass("magictime openUpLeftOut");
})
$("#openUpRightOut").click(function(){
    $(this).addClass("magictime openUpRightOut");
})
//PERSPECTIVE
$("#perspectiveDown").click(function(){
    $(this).addClass("magictime perspectiveDown");
})
$("#perspectiveUp").click(function(){
    $(this).addClass("magictime perspectiveUp");
})
$("#perspectiveLeft").click(function(){
    $(this).addClass("magictime perspectiveLeft");
})
$("#perspectiveRight").click(function(){
    $(this).addClass("magictime perspectiveRight");
})
$("#perspectiveDownReturn").click(function(){
    $(this).addClass("magictime perspectiveDownReturn");
})
$("#perspectiveUpReturn").click(function(){
    $(this).addClass("magictime perspectiveUpReturn");
})
$("#perspectiveLeftReturn").click(function(){
    $(this).addClass("magictime perspectiveLeftReturn");
})
$("#perspectiveRightReturn").click(function(){
    $(this).addClass("magictime perspectiveRightReturn");
})
//ROTATE
$("#rotateDown").click(function(){
    $(this).addClass("magictime rotateDown");
})
$("#rotateUp").click(function(){
    $(this).addClass("magictime rotateUp");
})
$("#rotateLeft").click(function(){
    $(this).addClass("magictime rotateLeft");
})
$("#rotateRight").click(function(){
    $(this).addClass("magictime rotateRight");
})
/* //SLIDE
$("#slideDown").click(function(){
    $(this).addClass("magictime slideDown");
})
$("#slideUp").click(function(){
    $(this).addClass("magictime slideUp");
})
$("#slideLeft").click(function(){
    $(this).addClass("magictime slideLeft");
})
$("#slideRight").click(function(){
    $(this).addClass("magictime slideRight");
})
$("#slideDownReturn").click(function(){
    $(this).addClass("magictime slideDownReturn");
})
$("#slideUpReturn").click(function(){
    $(this).addClass("magictime slideUpReturn");
})
$("#slideLeftReturn").click(function(){
    $(this).addClass("magictime slideLeftReturn");
})
$("#slideRightReturn").click(function(){
    $(this).addClass("magictime slideRightReturn");
})
//MATH
$("#swashOut").click(function(){
    $(this).addClass("magictime swashOut");
})
$("#swashIn").click(function(){
    $(this).addClass("magictime swashIn");
})
$("#foolishIn").click(function(){
    $(this).addClass("magictime foolishIn");
})
$("#holeOut").click(function(){
    $(this).addClass("magictime holeOut");
})
//TIN
$("#tinRightOut").click(function(){
    $(this).addClass("magictime tinRightOut");
})
$("#tinLeftOut").click(function(){
    $(this).addClass("magictime tinLeftOut");
})
$("#tinUpOut").click(function(){
    $(this).addClass("magictime tinUpOut");
})
$("#tinDownOut").click(function(){
    $(this).addClass("magictime tinDownOut");
})
$("#tinRightIn").click(function(){
    $(this).addClass("magictime tinRightIn");
})
$("#tinLeftIn").click(function(){
    $(this).addClass("magictime tinLeftIn");
})
$("#tinUpIn").click(function(){
    $(this).addClass("magictime tinUpIn");
})
$("#tinDownIn").click(function(){
    $(this).addClass("magictime tinDownIn");
})
//BOMB
$("#bombRightOut").click(function(){
    $(this).addClass("magictime bombRightOut");
})
$("#bombLeftOut").click(function(){
    $(this).addClass("magictime bombLeftOut");
})
//BOING
$("#boingInUp").click(function(){
    $(this).addClass("magictime boingInUp");
})
$("#boingOutDown").click(function(){
    $(this).addClass("magictime boingOutDown");
})
//ON THE SPACE
$("#spaceOutUp").click(function(){
    $(this).addClass("magictime spaceOutUp");
})
$("#spaceOutRight").click(function(){
    $(this).addClass("magictime spaceOutRight");
})
$("#spaceOutDown").click(function(){
    $(this).addClass("magictime spaceOutDown");
})
$("#spaceOutLeft").click(function(){
    $(this).addClass("magictime spaceOutLeft");
})
$("#spaceInUp").click(function(){
    $(this).addClass("magictime spaceInUp");
})
$("#spaceInRight").click(function(){
    $(this).addClass("magictime spaceInRight");
})
$("#spaceInDown").click(function(){
    $(this).addClass("magictime spaceInDown");
})
$("#spaceInLeft").click(function(){
    $(this).addClass("magictime spaceInLeft");
}) */
